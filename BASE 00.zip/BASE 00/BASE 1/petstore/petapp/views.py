from django.shortcuts import render ,redirect
from petapp.models import *
from django.contrib import messages
from math import ceil

def index(request):
    allProds=[]
    catprods=Product.objects.values('Product_Category','id')
    cats={item['Product_Category'] for item in catprods}
    for cat in cats:
        prod = Product.objects.filter(Product_Category=cat)
        n=len(prod)
        nSlides=n // 4 + ceil((n/4)-(n//4))
        allProds.append([prod, range(1,nSlides), nSlides])
    params= {"allProds": allProds}
    return render(request,"app/index.html",params)
    

def contact(request):
    if request.method=='POST':
        name=request.POST.get("name")
        email=request.POST.get("email")
        description=request.POST.get("desc")
        phone=request.POST.get("phone")
        myquery=Contact(name=name,email=email,desc=description,phone=phone)
        myquery.save()
        
        messages.info(request, 'We will get back soon')    
    return render(request,'app/contact.html')

def checkout(request):
    return render(request,'app/checkout.html')