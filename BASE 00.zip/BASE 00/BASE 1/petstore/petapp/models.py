from django.db import models

class Contact(models.Model):
    name=models.CharField(max_length=50)
    email=models.EmailField(max_length=254)
    desc=models.TextField(max_length=200)
    phone=models.IntegerField()


    def __str__(self):
        return self.name
    

class Product(models.Model):
    Product_ID=models.AutoField
    Product_Name=models.CharField( max_length=50)
    Product_Category=models.CharField(max_length=50 ,default="")
    Product_SubCategory=models.CharField(max_length=50)
    Product_Price=models.IntegerField(default=0)
    Product_Desc=models.CharField(max_length=300)
    Product_Image=models.ImageField(upload_to='images/image', height_field=None, width_field=None, max_length=None)
    
    def __str__(self):
        return self.Product_Name
    
   