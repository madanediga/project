
  //find out the cart from  local storage
  if (localstorage.getItem('cart')==null){
    var cart={};
  }
  else{
    cart=JSON.parse(localstorage.getItem('cart'))
    updateCart(cart);
  }
  //add or increment code
  //$('.cart').click(function(){
  $('.divpr').on('click', 'button.cart', function() {
      var idstr=this.id.toString();
      console.log(idstr)
      if(cart[idstr]!=undefined) {
        qty=cart[idstr][0]+1;
      }else{
        qty=1;
        name=document.getElementById('name'+idstr).innerHTML;
        price=document.getElementById('price'+idstr).innerHTML;
        cart[idstr]=[qty,name,price];
      }
      updateCart(cart);
      localstorage.setItem('cart',json.stringify(cart));
      document.getElementById("cart").innerHTML=Object.keys(cart).length;
      console.log(Object.keys(cart).length)
      document.getElementById("popcart").click();

  });
  //add popover to cart

  $('#popcart').popover();
  updatePopover(cart);
  function updatePopover(cart){
      console.log('we are inside update popover');
      var popStr="";
      var popStr= popStr+"<h5> cart for your items in my shopping cart</h5> <div class='mx-2 my-2'>";
        var i=1;
        for (var item in cart){
          popStr +"<b>" + i +"</b>.";
          popStr=popStr +document.getElementById('name'+item).innerHtml.slice(0,19)+"..."+"<b>" + cart[item][0]+"</b>"+"qty"+'<br>';
          i=i+1;
        }
        popStr=popStr +"</div> <a href='/checkout'><button class='btn btn-dark' oneclick='clearCart()' id='clearCart'>ClearCart</button>"
        document.getElementById('popcart').setAttribute('data-content',popStr);
        $('#popcart').popover('show');
        document.getElementById("popcart").click();
  }




  function clearCart(){
        cart=JSON.parse(localStorage.getItem('cart'));
        for(var item in cart){
            document.getElementById('div'+item).innerHTML='<button id=""' + item + '"class="btn-succcess cart ">Add to Cart</button>'
        }
        localStorage.clear();
        cart={};
        updateCart(cart);
      let clear=document.getElementById("popcart").click();
      document.getElementById("popcart").click();
  }

  function updateCart(cart){
    var sum =0;
    for(var item in cart){
      sum=sum+cart[item][0];
      document.getElementById('div'+item).innerHTML="<button id ='minus" + item + "'class='btn btn-success minus'>-</button> <span id='val"+item+"''>"+cart[item][0]+"</span> <button id='plus"+ item + "' class='btn btn-success plus'>+</button>";
    }
    localstorage.setItem('cart',json.stringify(cart));
    document.getElementById("cart").innerHTML=sum;
    console.log(cart);
    updatePopover(cart);
    document.getElementById("popcart").click();
  }
